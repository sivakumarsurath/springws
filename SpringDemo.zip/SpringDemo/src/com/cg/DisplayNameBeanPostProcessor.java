package com.cg;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;

public class DisplayNameBeanPostProcessor implements BeanPostProcessor {

	@Override
	public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {

		System.out.println("Post Process after initialization" + beanName);
		if(beanName.equals("triangle")) {
			((Triangle)bean).getPointC().setX(100);
			((Triangle)bean).getPointC().setY(100);
		}
		return bean;
	}

	@Override
	public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
		System.out.println("Post Process before initialization" + beanName);
		return bean;
	}

}
