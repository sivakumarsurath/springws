package com.cg.emp.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.emp.dto.Employee1;
import com.cg.emp.exception.Employee1Exception;
@Repository
public class EmployeeDaoImpl implements EmployeeDao {
	@PersistenceContext
	EntityManager entityManager;

	@Override
	public List<Employee1> getAllEmployees() throws Employee1Exception {
	
		try {
			TypedQuery<Employee1> query=
					entityManager.createQuery("from Employee1 order by id",Employee1.class);
			List<Employee1> employees=query.getResultList();
			
			return employees;
		} catch (Exception e) {
			
			throw new Employee1Exception(e.getMessage());
		}
	}

	@Override
	public List<Employee1> deleteEmployee(int id) throws Employee1Exception {
	
		try {
			Employee1 emp=entityManager.find(Employee1.class, id);
			entityManager.remove(emp);
			return getAllEmployees();
		} catch (Exception e) {
			throw new Employee1Exception(e.getMessage());
		}
	}

	@Override
	public List<Employee1> addEmployee(Employee1 employee) throws Employee1Exception {
		try {
			entityManager.persist(employee);
			return getAllEmployees();
		} catch (Exception e) {
			throw new Employee1Exception(e.getMessage());
		}
	}

	@Override
	public Employee1 getEmployeeById(int id) throws Employee1Exception {
		
		try {
			return entityManager.find(Employee1.class, id);
		} catch (Exception e) {
			
			throw new Employee1Exception(e.getMessage());
		}
	}

	@Override
	public List<Employee1> updateEmployee(Employee1 employee) throws Employee1Exception {
		try {
			entityManager.merge(employee);
			return getAllEmployees();
		} catch (Exception e) {
			throw new Employee1Exception(e.getMessage());
		}
	}

	
}
