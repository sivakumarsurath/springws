package com.cg.emp.dao;

import java.util.List;

import com.cg.emp.dto.Employee1;
import com.cg.emp.exception.Employee1Exception;

public interface EmployeeDao {

	List<Employee1> getAllEmployees() throws Employee1Exception;
	
	List<Employee1> deleteEmployee(int id) throws Employee1Exception;
	
	List<Employee1> addEmployee(Employee1 employee) throws Employee1Exception;
	
	Employee1 getEmployeeById(int id) throws Employee1Exception;
	
	List<Employee1> updateEmployee(Employee1 employee) throws Employee1Exception;
}
