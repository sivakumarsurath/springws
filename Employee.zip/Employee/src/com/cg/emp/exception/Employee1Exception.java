package com.cg.emp.exception;

public class Employee1Exception extends Exception{

	public Employee1Exception() {
		super();
		
	}
	
	public Employee1Exception(String message) {
		super(message);
	}
}
