package com.cg.emp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.emp.dao.EmployeeDao;
import com.cg.emp.dto.Employee1;
import com.cg.emp.exception.Employee1Exception;
@Service
@Transactional
public class EmployeeServiceImpl implements EmployeeService{

	@Autowired
	EmployeeDao employeeDao;
	@Override
	public List<Employee1> getAllEmployees() throws Employee1Exception {
	
		return employeeDao.getAllEmployees();
	}
	@Override
	public List<Employee1> deleteEmployee(int id) throws Employee1Exception {
		return employeeDao.deleteEmployee(id);
	}
	@Override
	public List<Employee1> addEmployee(Employee1 employee) throws Employee1Exception {
		
		return employeeDao.addEmployee(employee);
	}
	@Override
	public Employee1 getEmployeeById(int id) throws Employee1Exception {
		
		return employeeDao.getEmployeeById(id);
	}
	@Override
	public List<Employee1> updateEmployee(Employee1 employee) throws Employee1Exception {
		
		return employeeDao.updateEmployee(employee);
	}
	

}
