package com.capgemini1;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main1 {

	public static void main(String[] args) {
ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		
		Employee1 buisinessUnit = (Employee1) context.getBean("emp");
		buisinessUnit.show();
		buisinessUnit.getSbuDetails();
		
	}
}
