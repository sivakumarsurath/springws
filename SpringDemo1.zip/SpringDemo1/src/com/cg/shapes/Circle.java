package com.cg.shapes;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;
@Component
public class Circle {
	
	@Autowired

 private Point center;
	@Autowired
MessageSource messageSource;
public Point getCenter() {
	return center;
}


public void setCenter(Point center) {
	this.center = center;
}
 public void draw() {
	 String msg=messageSource.getMessage("greeting", null, "Default greeting Message", null);
	 System.out.println(msg);
	 
	 String draw=messageSource.getMessage("circle.drawing", null, "Default drawing Message", null);
	 String points=messageSource.getMessage("circle.points",new Object[] {center.getX(),center.getY()},"Default Msg",null);
	 System.out.println(points);
	 System.out.println(draw);
		/*
		 * System.out.println("Circle Drawn"); System.out.println();
		 */
 }
	/*
	 * public void myInit() { System.out.println("My Init Method executed"); }
	 * public void myDestroy() { System.out.println("My Destroy Method executed"); }
	 */
}
