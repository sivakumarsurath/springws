package com.cg.cust.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.cust.dao.CustomerRepository;
import com.cg.cust.dto.Customer;
import com.cg.cust.exception.CustomerException;
@Service
@Transactional
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	private CustomerRepository customerDao;
	@Override
	public List<Customer> getAllCustomers() throws CustomerException {
		
		try {
			return customerDao.findAll();
		} catch (Exception e) {
			
			throw new CustomerException(e.getMessage());
		}
	}
	@Override
	public List<Customer> deleteCustomer(int id) throws CustomerException {
		try {
			customerDao.delete(id);
			return getAllCustomers();
		} catch (Exception e) {
			throw new CustomerException(e.getMessage());
		}
	}
	@Override
	public List<Customer> addCustomer(Customer customer) throws CustomerException {
		try {
			customerDao.save(customer);
			return getAllCustomers();
		} catch (Exception e) {
			throw new CustomerException(e.getMessage());
		}
	}
	@Override
	public Customer getCustomerById(int id) throws CustomerException {
		
		try {
			return customerDao.findOne(id);
		} catch (Exception e) {
			throw new CustomerException(e.getMessage());
		}
	}
	@Override
	public List<Customer> updateCustomer(Customer customer ) throws CustomerException {
		try {
			customerDao.save(customer);
			return getAllCustomers();
		} catch (Exception e) {
			throw new CustomerException(e.getMessage());
		}
	}
	
	
}
